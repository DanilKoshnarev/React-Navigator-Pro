export class Data {
  constructor(id, name) {
    this.id = id;
    this.name = name;
  }
}