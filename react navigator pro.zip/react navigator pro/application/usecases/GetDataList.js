export class GetDataList {
  constructor(dataRepository) {
    this.dataRepository = dataRepository;
  }

  async execute() {
    return await this.dataRepository.getAll();
  }
}