export class DataRepository {
  getAll() {
    throw new Error("Method not implemented");
  }
}