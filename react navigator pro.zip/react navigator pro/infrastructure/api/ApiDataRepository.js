import { DataRepository } from "../../application/repositories/DataRepository";

export class ApiDataRepository extends DataRepository {
  async getAll() {

    const response = await fetch("/api/data");
    const data = await response.json();
    return data.map(item => new Data(item.id, item.name));
  }
}