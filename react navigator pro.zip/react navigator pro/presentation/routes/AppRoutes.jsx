import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from '../components/Layout';
import DataListPage from '../pages/DataListPage';
import DataPage from '../pages/DataPage';
import DataDeletePage from '../pages/DataDeletePage';
import DataCreatePage from '../pages/DataCreatePage';

const AppRoutes = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route path="data" element={<DataListPage />} />
        <Route path="data/:id" element={<DataPage />} />
        <Route path="data/delete" element={<DataDeletePage />} />
        <Route path="data/create" element={<DataCreatePage />} />
      </Route>
    </Routes>
  </Router>
);

export default AppRoutes;