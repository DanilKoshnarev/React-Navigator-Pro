import React, { useEffect, useState } from 'react';
import { GetDataList } from '../../application/usecases/GetDataList';
import { ApiDataRepository } from '../../infrastructure/api/ApiDataRepository';

const dataRepository = new ApiDataRepository();
const getDataList = new GetDataList(dataRepository);

const DataListPage = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const result = await getDataList.execute();
      setData(result);
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Data List</h2>
      <ul>
        {data.map(item => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default DataListPage;